import Foundation
// Workaround to check if some Optional type is nil
protocol OptionalProvider {
  var isNil: Bool { get }
}
extension Optional: OptionalProvider {
  var isNil: Bool { return self == nil }
}
// Your protocol
protocol PropertyLoopable {
  var allProperties: [Any] { get }
}
extension PropertyLoopable {
  var allProperties: [Any] {
    var result: [Any] = []
    let mirror: Mirror = Mirror(reflecting: self)
    guard let style = mirror.displayStyle, style == .struct || style == .class else {
      return []
    }
    mirror.children.forEach { key, value in
      if let keyValue = key {
        if case let .some(unwrappedValue) = value as Optional<AnyObject> {
          result.append()
        } else {
          result.append(value)
        }
      }
    }
    
    return result
  }
  
  // This function could be here without definition in Protocol
  // without definition in protocol, this function can not be overriden
  func isNil(_ input: Any) -> Bool {
    // As optional type conforms OptionalProvider, we can make a cast to it
    // if cast is success, then we can check if it is nil
    return (input as? OptionalProvider)?.isNil ?? false
  }
}
extension User: PropertyLoopable {}

struct User {
  let name: String?
  let age: Int?
}

let user = User(name: nil, age: 10)

print(user.allProperties.isEmpty)
